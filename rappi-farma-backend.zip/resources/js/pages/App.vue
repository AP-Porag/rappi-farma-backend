<template>
    <div>
        <router-view></router-view>
    </div>
</template>

<script>
import {mapActions} from 'vuex'
import store from "../store";
export default {
    name: "App",
}
</script>

<style scoped>

</style>
